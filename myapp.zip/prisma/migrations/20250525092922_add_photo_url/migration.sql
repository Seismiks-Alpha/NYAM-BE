-- AlterTable
ALTER TABLE "User" ADD COLUMN     "photoUrl" TEXT;
