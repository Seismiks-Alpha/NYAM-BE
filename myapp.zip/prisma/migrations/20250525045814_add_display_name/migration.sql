-- AlterTable
ALTER TABLE "User" ADD COLUMN     "displayName" TEXT NOT NULL DEFAULT 'Pengguna';
